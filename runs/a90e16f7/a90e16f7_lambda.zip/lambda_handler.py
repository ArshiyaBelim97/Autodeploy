
import awsgi
from app.app import app as flask_app

def handler(event, context):
    return awsgi.response(flask_app, event, context)
